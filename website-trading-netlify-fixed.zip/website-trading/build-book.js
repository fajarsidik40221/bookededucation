// Mengekstrak isi buku dari HTML sumber menjadi data/book.json (dipakai server; TIDAK dikirim sebelum bayar)
const fs=require('fs');
const src=process.argv[2]||'../buku-trading-55-bab.html';
let sc=fs.readFileSync(src,'utf8').match(/<script>([\s\S]*)<\/script>/)[1].split('var app=')[0];
const r=new Function(sc+';return {P:P,C:C,first:first,pick:pick}')();
const {P,C,first,pick}=r;
const pt=(q,n)=>{const a=q.p||q.tbl.map(x=>x[0]+': '+x[1]);return a[n%a.length]};
const chapters=P.slice(1).map((p,i)=>{const k=i+1,c1=pt(p,k),c2=p.i,c3=first(p.d);
 return {n:k,id:p.id,t:p.t,i:p.i,p:p.p||null,d:p.d,tbl:p.tbl||null,chart:p.c?C[p.c]():null,
 quiz:[['Manakah yang termasuk pembahasan “'+p.t+'”?',c1,pick(k,q=>pt(q,0),c1)],['Manakah ringkasan yang tepat untuk “'+p.t+'”?',c2,pick(k,q=>q.i,c2)],['Manakah kalimat yang berasal dari penjelasan detail “'+p.t+'”?',c3,pick(k,q=>first(q.d),c3)]]}});
fs.writeFileSync('data/book.json',JSON.stringify({title:'Panduan Trading untuk Pemula',chapters}));
console.log(chapters.length,'bab ditulis ke data/book.json');
