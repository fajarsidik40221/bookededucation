# Panduan Trading untuk Pemula — Netlify

Website penjualan buku digital 55 bab dengan checkout DANA/OVO, bukti transfer, panel admin, dan akses pembaca.

## Data pembayaran (dipertahankan)

- **DANA:** 081385913359 — **FAJAR SIDIK**
- **OVO:** 085714865098 — **RADITYA MONTELA**
- QRIS tidak digunakan.
- Harga dasar default: **Rp15.000**. Nominal pesanan ditambah kode unik Rp1–Rp99 agar transaksi lebih mudah dicocokkan.

Pastikan nama dan nomor penerima benar serta akun aktif sebelum website dipublikasikan.

## Perubahan pada versi ini

- Username admin: `bookededucation`.
- Password admin yang diminta: `semangatsukses` (atur sebagai Environment Variable Netlify, jangan ditulis di source/GitHub).
- Batas perangkat diubah menjadi **tanpa batas** (`MAX_DEVICES=0`).
- DANA dan OVO tetap menggunakan nomor di atas.
- Validasi kontak pembeli diperketat.
- Pesanan dan bukti pembayaran di Netlify disimpan menggunakan Netlify Blobs.

## Penting tentang pembayaran

Sistem ini menggunakan **transfer manual**. Website hanya membuat instruksi pembayaran dan menerima bukti transfer. Admin tetap harus mengecek mutasi DANA/OVO secara langsung sebelum menekan Setujui. Gambar bukti tidak membuktikan dana sudah masuk.

Tidak ada cara menjamin pembayaran selalu bebas error, karena koneksi, layanan Netlify, dan aplikasi e-wallet berada di luar kendali website. Ikuti pengujian di bawah sebelum membagikan link ke pembeli. Pembayaran otomatis memerlukan payment gateway resmi dan webhook; jangan mengaku otomatis jika belum diintegrasikan.

## Deploy melalui GitHub dan Netlify

### A. Siapkan ZIP

1. Ekstrak ZIP proyek.
2. Buka folder `website-trading`.
3. Pastikan isi folder yang diunggah ke GitHub langsung berisi `netlify.toml`, `package.json`, `public/`, `netlify/functions/`, dan `data/book.json` — jangan sampai semuanya tersimpan satu tingkat folder lebih dalam.
4. Jangan unggah `.env`, password, `node_modules/`, `data/orders.json`, atau bukti pembayaran.

### B. Upload ke GitHub

1. Masuk ke https://github.com lalu login.
2. Tekan **New repository**.
3. Isi nama, misalnya `panduan-trading`, pilih **Private** agar source tidak terbuka untuk umum, lalu **Create repository**.
4. Pilih **Add file → Upload files**.
5. Upload seluruh isi folder `website-trading` (bukan ZIP-nya).
6. Tekan **Commit changes**.

### C. Hubungkan repository ke Netlify

1. Masuk ke https://app.netlify.com.
2. Pilih **Add new project → Import an existing project**.
3. Pilih **Deploy with GitHub**, izinkan akses GitHub, lalu pilih repository `panduan-trading`.
4. Build settings:
   - Build command: kosongkan.
   - Publish directory: `public`.
   - Functions directory: `netlify/functions`.
5. Tekan **Deploy**.

File `netlify.toml` sudah mengatur publish directory, functions directory, dan routing `/api/*`.

### D. Atur Environment Variables di Netlify

Setelah proyek dibuat, buka **Project configuration / Site configuration → Environment variables**. Tambahkan variabel berikut satu per satu:

| Key | Value |
|---|---|
| `ADMIN_USERNAME` | `bookededucation` |
| `ADMIN_PASSWORD` | `semangatsukses` |
| `MAX_DEVICES` | `0` |
| `PRICE` | `15000` |
| `ORDER_TTL_HOURS` | `24` |

Jika Netlify menampilkan pilihan scope, pastikan variabel tersedia untuk **Functions**. Jangan membuat variabel bernama lain atau menambahkan spasi di awal/akhir nilainya.

**Keamanan:** password yang diminta relatif mudah ditebak. Untuk website publik, lebih aman ganti dengan password acak yang lebih panjang. Jika tetap memakai password tersebut, jangan membagikannya kepada pembeli dan jangan memasukkannya ke file yang diunggah ke GitHub.

### E. Deploy ulang

1. Setelah Environment Variables disimpan, buka **Deploys**.
2. Pilih **Trigger deploy → Deploy site**.
3. Tunggu sampai status deploy sukses.
4. Buka alamat Netlify yang diberikan, misalnya `https://nama-situs.netlify.app`.
5. Panel admin ada di `https://nama-situs.netlify.app/admin`.

## Cara tes sebelum dipakai pembeli

1. Buka website melalui link Netlify.
2. Tekan **Beli sekarang**, pilih DANA atau OVO, isi nomor kontak, lalu buat pesanan.
3. Pastikan halaman menampilkan nomor penerima dan nama yang benar:
   - DANA: 081385913359 — FAJAR SIDIK
   - OVO: 085714865098 — RADITYA MONTELA
4. Cek nominal total yang tampil. Transfer harus sesuai nominal termasuk kode unik.
5. Lakukan transaksi percobaan sungguhan dengan nominal kecil, atau minta orang tepercaya melakukan transaksi.
6. Unggah bukti JPG/PNG/WEBP maksimal 4 MB dan tekan **Kirim bukti pembayaran**.
7. Buka `/admin`, login, pastikan pesanan dan bukti terlihat.
8. Cocokkan transaksi dengan mutasi DANA/OVO. Hanya jika dana benar-benar masuk, tekan **Setujui**.
9. Kembali ke halaman pembeli dan tekan **Periksa status pesanan**. Akses materi harus terbuka.
10. Uji beberapa perangkat/browser. Batas perangkat sekarang tidak diterapkan.

## Jika pembayaran atau website error

- **`ADMIN_USERNAME dan ADMIN_PASSWORD belum diatur`**: periksa Environment Variables, nama variabel harus persis, lalu deploy ulang.
- **`Server error` / HTTP 500**: buka Netlify → Functions → `api` → Logs. Periksa apakah fungsi berjalan dan Netlify Blobs tersedia.
- **Pesanan tidak dibuat**: pastikan deploy fungsi `api` sukses dan URL `/api/config` dapat dibuka.
- **Bukti gagal diunggah**: gunakan JPG/PNG/WEBP, ukuran maksimal 4 MB, koneksi stabil, lalu coba lagi.
- **Admin tidak bisa login**: pastikan username/password sama persis dengan Environment Variables dan deploy ulang setelah perubahan.
- **Pesanan kedaluwarsa**: masa berlaku default 24 jam. Buat pesanan baru jika melewati batas.

## Penyimpanan dan batas sistem

Versi Netlify memakai Netlify Blobs sehingga pesanan tidak bergantung pada filesystem sementara Functions. Jangan menghapus site atau store Blobs jika ingin mempertahankan data transaksi. Perangkat pembeli tidak dibatasi, tetapi akses tetap terkait token pesanan yang disetujui admin.

## Menjalankan lokal (opsional)

Gunakan Node.js 20+. Salin `.env.example` menjadi `.env`, ganti password dengan nilai rahasia, lalu:

```bash
npm install
# isi environment di terminal atau gunakan pengelola .env lokal
npm start
```

Buka `http://localhost:3000` dan `http://localhost:3000/admin`. Server lokal memakai file `data/orders.json`; ini berbeda dari penyimpanan Netlify Blobs.
