// Website buku digital berbayar. Node.js 18+, tanpa dependensi eksternal.
// Pembayaran DANA/OVO diverifikasi manual oleh admin. Untuk otomatisasi, integrasikan payment gateway resmi.
'use strict';
const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const CFG = {
  port: Number(process.env.PORT || 3000),
  adminUsername: process.env.ADMIN_USERNAME || 'bookededucation',
  adminPassword: process.env.ADMIN_PASSWORD || '',
  dana: process.env.DANA_NUMBER || '081385913359',
  danaName: process.env.DANA_NAME || 'FAJAR SIDIK',
  ovo: process.env.OVO_NUMBER || '085714865098',
  ovoName: process.env.OVO_NAME || 'RADITYA MONTELA',
  price: Number(process.env.PRICE || 15000),
  ttlMs: Number(process.env.ORDER_TTL_HOURS || 24) * 3600000,
  maxDevices: Number(process.env.MAX_DEVICES ?? 0),
};
if (CFG.adminPassword.length < 12) {
  console.error('ADMIN_PASSWORD wajib diisi dan minimal 12 karakter.');
  process.exit(1);
}
if (!Number.isFinite(CFG.price) || CFG.price < 1000) throw new Error('PRICE tidak valid.');

const DATA_DIR = path.join(__dirname, 'data');
const DB_FILE = path.join(DATA_DIR, 'orders.json');
const PROOF_DIR = path.join(DATA_DIR, 'proofs');
fs.mkdirSync(PROOF_DIR, { recursive: true });
const BOOK = JSON.parse(fs.readFileSync(path.join(DATA_DIR, 'book.json'), 'utf8'));
let orders = [];
try { orders = JSON.parse(fs.readFileSync(DB_FILE, 'utf8')); if (!Array.isArray(orders)) orders = []; } catch {}
const save = () => fs.writeFileSync(DB_FILE, JSON.stringify(orders, null, 2), { mode: 0o600 });
const now = () => Date.now();
const rid = (n = 16) => crypto.randomBytes(n).toString('hex');
const eq = (a, b) => { const x = Buffer.from(String(a)); const y = Buffer.from(String(b)); return x.length === y.length && crypto.timingSafeEqual(x, y); };
const clean = (s, n) => String(s || '').replace(/[<>\u0000-\u001f]/g, '').trim().slice(0, n);
const json = (res, code, obj) => { res.writeHead(code, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff' }); res.end(JSON.stringify(obj)); };
function readBody(req, max = 6 * 1024 * 1024) {
  return new Promise((resolve, reject) => {
    const chunks = []; let size = 0;
    req.on('data', c => { size += c.length; if (size > max) { reject(new Error('Ukuran data terlalu besar.')); req.destroy(); } else chunks.push(c); });
    req.on('end', () => { try { resolve(JSON.parse(Buffer.concat(chunks).toString('utf8') || '{}')); } catch { reject(new Error('Format JSON tidak valid.')); } });
    req.on('error', reject);
  });
}
const live = o => { if (!['disetujui', 'ditolak', 'kedaluwarsa'].includes(o.status) && now() > o.expiresAt) { o.status = 'kedaluwarsa'; save(); } return o; };
const hits = new Map();
function limited(ip) { const t = now(), a = (hits.get(ip) || []).filter(x => t - x < 3600000); a.push(t); hits.set(ip, a); return a.length > 10; }
function uniqueAmount() {
  const used = new Set(orders.map(live).filter(o => ['menunggu_transfer', 'menunggu_verifikasi'].includes(o.status)).map(o => o.amount));
  for (let i = 0; i < 200; i++) { const amount = CFG.price + 1 + Math.floor(Math.random() * 99); if (!used.has(amount)) return amount; }
  return null;
}
const isAdmin = req => eq(req.headers['x-admin-user'] || '', CFG.adminUsername) && eq(req.headers['x-admin-key'] || '', CFG.adminPassword);
const publicOrder = o => ({ id: o.id, status: o.status, amount: o.amount, paymentMethod: o.paymentMethod, dana: CFG.dana, danaName: CFG.danaName, ovo: CFG.ovo, ovoName: CFG.ovoName, expiresAt: o.expiresAt, token: o.status === 'disetujui' ? o.token : undefined });
function tokenOrder(req) {
  const token = req.headers['x-token'], device = clean(req.headers['x-device'], 80);
  const o = orders.find(x => x.status === 'disetujui' && x.token && token && eq(x.token, token));
  if (!o || !device) return null;
  o.devices = o.devices || [];
  if (!o.devices.includes(device)) { if (CFG.maxDevices > 0 && o.devices.length >= CFG.maxDevices) return 'limit'; o.devices.push(device); save(); }
  return o;
}
function proofData(o) {
  if (!o.proofFile) return null;
  try { const f = path.join(PROOF_DIR, o.proofFile); const ext = path.extname(f).slice(1); const mime = ext === 'jpg' ? 'image/jpeg' : 'image/' + ext; return `data:${mime};base64,${fs.readFileSync(f).toString('base64')}`; } catch { return null; }
}
const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, 'http://localhost'), p = url.pathname, m = req.method;
  try {
    if (m === 'GET' && (p === '/' || p === '/admin')) {
      const file = p === '/' ? 'index.html' : 'admin.html';
      res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8', 'X-Content-Type-Options': 'nosniff', 'Referrer-Policy': 'strict-origin-when-cross-origin', 'X-Frame-Options': 'DENY', 'Content-Security-Policy': "default-src 'self' https: data:; img-src 'self' data: https:; style-src 'self' 'unsafe-inline'; script-src 'self' 'unsafe-inline'; connect-src 'self'; frame-ancestors 'none'" });
      return res.end(fs.readFileSync(path.join(__dirname, 'public', file)));
    }
    if (m === 'GET' && p === '/api/config') return json(res, 200, { title: BOOK.title, price: CFG.price, dana: CFG.dana, danaName: CFG.danaName, ovo: CFG.ovo, ovoName: CFG.ovoName, toc: BOOK.chapters.map(c => ({ n: c.n, id: c.id, t: c.t })) });
    if (m === 'POST' && p === '/api/orders') {
      if (limited(req.socket.remoteAddress || 'unknown')) return json(res, 429, { error: 'Terlalu banyak permintaan. Coba lagi nanti.' });
      const b = await readBody(req, 12000), method = ['DANA', 'OVO'].includes(b.paymentMethod) ? b.paymentMethod : '', contact = clean(b.contact, 60);
      if (!method) return json(res, 400, { error: 'Pilih metode pembayaran DANA atau OVO.' });
      if (contact.length < 5) return json(res, 400, { error: 'Masukkan nomor WhatsApp/kontak yang valid.' });
      const amount = uniqueAmount(); if (!amount) return json(res, 503, { error: 'Server sibuk, coba lagi sebentar.' });
      const o = { id: rid(8), status: 'menunggu_transfer', amount, paymentMethod: method, contact, sender: '', createdAt: now(), expiresAt: now() + CFG.ttlMs };
      orders.push(o); save(); return json(res, 201, publicOrder(o));
    }
    let match;
    if ((match = p.match(/^\/api\/orders\/([a-f0-9]{16})(\/confirm)?$/))) {
      const o = orders.find(x => x.id === match[1]); if (!o) return json(res, 404, { error: 'Pesanan tidak ditemukan.' }); live(o);
      if (m === 'GET' && !match[2]) return json(res, 200, publicOrder(o));
      if (m === 'POST' && match[2]) {
        if (!['menunggu_transfer', 'menunggu_verifikasi'].includes(o.status)) return json(res, 409, { error: 'Pesanan sudah ' + o.status + '.' });
        const b = await readBody(req); const sender = clean(b.sender, 60); if (sender.length < 2) return json(res, 400, { error: 'Masukkan nama pengirim.' });
        const data = String(b.proof || ''); const allowed = data.match(/^data:image\/(jpeg|jpg|png|webp);base64,([A-Za-z0-9+/=]+)$/);
        if (!allowed) return json(res, 400, { error: 'Unggah bukti pembayaran berupa JPG, PNG, atau WEBP.' });
        const bytes = Buffer.from(allowed[2], 'base64'); if (!bytes.length || bytes.length > 4 * 1024 * 1024) return json(res, 400, { error: 'Ukuran bukti maksimal 4 MB.' });
        const ext = allowed[1] === 'jpeg' ? 'jpg' : allowed[1]; const file = `${o.id}.${ext}`;
        fs.writeFileSync(path.join(PROOF_DIR, file), bytes, { mode: 0o600 });
        o.proofFile = file; o.sender = sender; o.status = 'menunggu_verifikasi'; o.confirmedAt = now(); save(); return json(res, 200, publicOrder(o));
      }
    }
    if (m === 'GET' && (match = p.match(/^\/api\/chapter\/(\d+)$/))) {
      const o = tokenOrder(req); if (o === 'limit') return json(res, 403, { error: `Batas perangkat (${CFG.maxDevices}) tercapai.` }); if (!o) return json(res, 401, { error: 'Akses tidak valid. Selesaikan pembayaran terlebih dahulu.' });
      const chapter = BOOK.chapters.find(c => c.n === Number(match[1])); return chapter ? json(res, 200, chapter) : json(res, 404, { error: 'Bab tidak ditemukan.' });
    }
    if (p.startsWith('/api/admin/')) {
      if (!isAdmin(req)) return json(res, 401, { error: 'Password admin salah.' });
      if (m === 'GET' && p === '/api/admin/orders') return json(res, 200, orders.slice().reverse().map(live).map(o => ({ id: o.id, status: o.status, amount: o.amount, paymentMethod: o.paymentMethod, contact: o.contact, sender: o.sender, createdAt: o.createdAt, confirmedAt: o.confirmedAt, expiresAt: o.expiresAt, devices: (o.devices || []).length, proof: proofData(o) })));
      if ((match = p.match(/^\/api\/admin\/orders\/([a-f0-9]{16})\/(approve|reject)$/)) && m === 'POST') {
        const o = orders.find(x => x.id === match[1]); if (!o) return json(res, 404, { error: 'Pesanan tidak ditemukan.' });
        if (o.status !== 'menunggu_verifikasi' && match[2] === 'approve') return json(res, 409, { error: 'Pesanan belum mengirim bukti pembayaran.' });
        if (match[2] === 'approve') { o.status = 'disetujui'; o.token = o.token || rid(24); o.approvedAt = now(); }
        else o.status = 'ditolak'; save(); return json(res, 200, { ok: true, status: o.status });
      }
    }
    return json(res, 404, { error: 'Endpoint tidak ditemukan.' });
  } catch (e) { console.error(e); if (!res.headersSent) json(res, 500, { error: e.message === 'Ukuran data terlalu besar.' ? e.message : 'Terjadi kesalahan server.' }); }
});
server.listen(CFG.port, '0.0.0.0', () => console.log(`Website aktif di port ${CFG.port}. Admin: /admin`));
