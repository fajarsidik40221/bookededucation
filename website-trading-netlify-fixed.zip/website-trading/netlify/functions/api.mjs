import { getStore } from "@netlify/blobs";
import crypto from "node:crypto";
import BOOK from "../../data/book.json" with { type: "json" };
const store = getStore({ name: "panduan-trading-orders", consistency: "strong" });
const CFG = {
  adminUsername: process.env.ADMIN_USERNAME || "",
  adminPassword: process.env.ADMIN_PASSWORD || "",
  dana: "081385913359", danaName: "FAJAR SIDIK",
  ovo: "085714865098", ovoName: "RADITYA MONTELA",
  price: Number(process.env.PRICE || 15000),
  ttlMs: Number(process.env.ORDER_TTL_HOURS || 24) * 3600000,
  maxDevices: Number(process.env.MAX_DEVICES ?? 0),
};
const json = (data, status = 200) => Response.json(data, { status, headers: { "Cache-Control": "no-store", "X-Content-Type-Options": "nosniff" } });
const clean = (s, n) => String(s || "").replace(/[<>\u0000-\u001f]/g, "").trim().slice(0, n);
const rid = (n = 16) => crypto.randomBytes(n).toString("hex");
const eq = (a, b) => { const x = Buffer.from(String(a || "")); const y = Buffer.from(String(b || "")); return x.length === y.length && x.length > 0 && crypto.timingSafeEqual(x, y); };
const key = id => `order-${id}`;
async function getOrder(id) { return await store.get(key(id), { type: "json", consistency: "strong" }); }
async function saveOrder(o) { await store.setJSON(key(o.id), o); }
function expire(o) { if (!['disetujui', 'ditolak', 'kedaluwarsa'].includes(o.status) && Date.now() > o.expiresAt) o.status = 'kedaluwarsa'; return o; }
function publicOrder(o) { return { id:o.id, status:o.status, amount:o.amount, paymentMethod:o.paymentMethod, dana:CFG.dana, danaName:CFG.danaName, ovo:CFG.ovo, ovoName:CFG.ovoName, expiresAt:o.expiresAt, token:o.status==='disetujui'?o.token:undefined }; }
function isAdmin(req) { return eq(req.headers.get("x-admin-user"), CFG.adminUsername) && eq(req.headers.get("x-admin-key"), CFG.adminPassword) && CFG.adminUsername.length > 0 && CFG.adminPassword.length >= 12; }
async function allOrders() { const { blobs } = await store.list({ prefix: "order-" }); const out=[]; for (const b of blobs) { const o=await store.get(b.key,{type:"json",consistency:"strong"}); if(o){expire(o);out.push(o);} } return out; }
const hits = new Map();
function limited(ip) { const t=Date.now(), a=(hits.get(ip)||[]).filter(x=>t-x<3600000); a.push(t); hits.set(ip,a); return a.length>10; }

export default async (req) => {
  try {
    if (!CFG.adminUsername || CFG.adminPassword.length < 12) return json({ error: "ADMIN_USERNAME dan ADMIN_PASSWORD belum diatur dengan benar di Netlify." }, 503);
    if (!Number.isFinite(CFG.price) || CFG.price < 1000) return json({ error: "Konfigurasi harga tidak valid." }, 500);
    const url = new URL(req.url);
    let p = url.pathname;
    // Netlify redirect may preserve the function prefix; normalize it to /api/...
    p = p.replace(/^\/.netlify\/functions\/api/, "/api");
    if (!p.startsWith("/api/")) p = "/api" + (p.startsWith("/") ? p : "/" + p);
    const m = req.method;

    if (m === "GET" && p === "/api/config") return json({ title:BOOK.title, price:CFG.price, dana:CFG.dana, danaName:CFG.danaName, ovo:CFG.ovo, ovoName:CFG.ovoName, toc:BOOK.chapters.map(c=>({n:c.n,id:c.id,t:c.t})) });

    if (m === "POST" && p === "/api/orders") {
      const ip = req.headers.get("x-nf-client-connection-ip") || "unknown";
      if (limited(ip)) return json({error:"Terlalu banyak permintaan. Coba lagi nanti."},429);
      const b=await req.json(); const method=["DANA","OVO"].includes(b.paymentMethod)?b.paymentMethod:"";
      if(!method) return json({error:"Pilih metode pembayaran DANA atau OVO."},400);
      const contact=clean(b.contact,60); if(contact.length<5) return json({error:"Masukkan nomor WhatsApp/kontak yang valid."},400);
      const existing=await allOrders(); const used=new Set(existing.filter(o=>["menunggu_transfer","menunggu_verifikasi"].includes(o.status)).map(o=>o.amount));
      let amount=null; for(let i=0;i<200;i++){const n=CFG.price+1+Math.floor(Math.random()*99);if(!used.has(n)){amount=n;break;}}
      if(!amount) return json({error:"Server sibuk, coba lagi sebentar."},503);
      const o={id:rid(8),status:"menunggu_transfer",amount,paymentMethod:method,contact,sender:"",createdAt:Date.now(),expiresAt:Date.now()+CFG.ttlMs};
      await saveOrder(o); return json(publicOrder(o),201);
    }

    let match=p.match(/^\/api\/orders\/([a-f0-9]{16})(\/confirm)?$/);
    if(match){
      const o=await getOrder(match[1]); if(!o)return json({error:"Pesanan tidak ditemukan."},404); expire(o); if(o.status==="kedaluwarsa")await saveOrder(o);
      if(m==="GET"&&!match[2])return json(publicOrder(o));
      if(m==="POST"&&match[2]){
        if(!["menunggu_transfer","menunggu_verifikasi"].includes(o.status))return json({error:"Pesanan sudah "+o.status+"."},409);
        const b=await req.json();const sender=clean(b.sender,60);if(sender.length<2)return json({error:"Masukkan nama pengirim."},400);
        const data=String(b.proof||"");const allowed=data.match(/^data:image\/(jpeg|jpg|png|webp);base64,([A-Za-z0-9+/=]+)$/);if(!allowed)return json({error:"Unggah bukti JPG, PNG, atau WEBP."},400);
        const bytes=Buffer.from(allowed[2],"base64");if(!bytes.length||bytes.length>4*1024*1024)return json({error:"Ukuran bukti maksimal 4 MB."},400);
        o.proof=data;o.sender=sender;o.status="menunggu_verifikasi";o.confirmedAt=Date.now();await saveOrder(o);return json(publicOrder(o));
      }
    }

    match=p.match(/^\/api\/chapter\/(\d+)$/);
    if(m==="GET"&&match){
      const token=req.headers.get("x-token"),device=clean(req.headers.get("x-device"),80);if(!token||!device)return json({error:"Akses tidak valid. Selesaikan pembayaran terlebih dahulu."},401);
      const id=await store.get(`token-${token}`,{type:"text",consistency:"strong"});if(!id)return json({error:"Akses tidak valid. Selesaikan pembayaran terlebih dahulu."},401);
      const o=await getOrder(id);if(!o||o.status!=="disetujui"||o.token!==token)return json({error:"Akses tidak valid."},401);
      o.devices=o.devices||[];if(!o.devices.includes(device)){if(CFG.maxDevices>0&&o.devices.length>=CFG.maxDevices)return json({error:`Batas perangkat (${CFG.maxDevices}) tercapai.`},403);o.devices.push(device);await saveOrder(o);}
      const chapter=BOOK.chapters.find(c=>c.n===Number(match[1]));return chapter?json(chapter):json({error:"Bab tidak ditemukan."},404);
    }

    if(p==="/api/admin/orders"&&m==="GET"){
      if(!isAdmin(req))return json({error:"Password admin salah."},401);
      const rows=(await allOrders()).sort((a,b)=>b.createdAt-a.createdAt).map(o=>({id:o.id,status:o.status,amount:o.amount,paymentMethod:o.paymentMethod,contact:o.contact,sender:o.sender,createdAt:o.createdAt,confirmedAt:o.confirmedAt,expiresAt:o.expiresAt,devices:(o.devices||[]).length,proof:o.proof||null}));return json(rows);
    }
    match=p.match(/^\/api\/admin\/orders\/([a-f0-9]{16})\/(approve|reject)$/);
    if(match&&m==="POST"){
      if(!isAdmin(req))return json({error:"Password admin salah."},401);
      const o=await getOrder(match[1]);if(!o)return json({error:"Pesanan tidak ditemukan."},404);
      if(match[2]==="approve"){
        if(o.status!=="menunggu_verifikasi")return json({error:"Pesanan belum mengirim bukti pembayaran."},409);
        o.status="disetujui";o.token=o.token||rid(24);o.approvedAt=Date.now();await store.set(`token-${o.token}`,o.id);
      } else o.status="ditolak";
      await saveOrder(o);return json({ok:true,status:o.status});
    }
    return json({error:"Endpoint tidak ditemukan."},404);
  } catch (err) { console.error(err); return json({error:"Terjadi kesalahan server. Periksa log Netlify Functions."},500); }
};
